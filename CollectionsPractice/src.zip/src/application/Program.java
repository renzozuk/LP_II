package application;

import entities.Turma;

import java.util.Locale;

public class Program {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Turma turma = new Turma();
        turma.adicionarAlunoATurma(5.0, 5.1, 9.0, 0.3);
        turma.adicionarAlunoATurma(7.0, 0.0, 0.5, 0.0);
        turma.adicionarAlunoATurma(1.0, 2.3, 4.7, 0.4);
        System.out.print(turma);
    }
}
