package entities;

public class Aluno {
    private Prova prova1;
    private Prova prova2;

    public Aluno(Prova prova1, Prova prova2) {
        this.prova1 = prova1;
        this.prova2 = prova2;
    }

    public double calcularMedia(){
        return (prova1.calcularNotaTotal() + prova2.calcularNotaTotal()) / 2.0;
    }

    @Override
    public String toString(){
        return "Prova 1: " + String.format("%.1f", prova1.calcularNotaTotal()) + "\n"
                + "Prova 2: " + String.format("%.1f", prova2.calcularNotaTotal()) + "\n"
                + "Média do aluno: " + String.format("%.1f", calcularMedia()) + "\n";
    }
}
