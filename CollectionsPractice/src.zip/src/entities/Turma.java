package entities;

import java.util.ArrayList;
import java.util.List;

public class Turma {
    private List<Aluno> alunos = new ArrayList<>();

    public Turma(){}

    public void adicionarAlunoATurma(double nota1Parte1, double nota1Parte2, double nota2Parte1, double nota2Parte2){
        alunos.add(new Aluno(new Prova(nota1Parte1, nota1Parte2), new Prova(nota2Parte1, nota2Parte2)));
    }

    public double calcularMedia(){
        double media = 0.0;
        for (Aluno aluno : alunos) {
            media += aluno.calcularMedia();
        }
        media /= alunos.size();
        return media;
    }

    @Override
    public String toString(){
        String result = "# DESEMPENHO DA TURMA #" + "\n" + "\n";
        for(int i = 0; i < alunos.size(); i++){
            result += "===== Aluno " + (i + 1) + " =====" + "\n";
            result += alunos.get(i) + "\n";
        }
        result += "Média da turma: " + String.format("%.1f", calcularMedia()) + "\n";
        return result;
    }
}
