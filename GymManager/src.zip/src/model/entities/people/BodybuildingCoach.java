package model.entities.people;

public class BodybuildingCoach extends PersonalTrainer {
    public BodybuildingCoach(String name, int id) {
        super(name, id);
    }
}
