package application;

import model.entities.elements.WorkSchedule;
import model.entities.elements.Workout;
import model.entities.people.BodybuildingCoach;
import model.entities.people.Customer;
import model.entities.people.PersonalTrainer;
import model.entities.people.Receptionist;
import model.entities.people.SwimmingTeacher;
import model.services.GymDatabase;

import java.time.DayOfWeek;

public class NatalFitness {
    public static void main(String[] args) {
        GymDatabase gdb = new GymDatabase();

        Receptionist lg = new Receptionist("Lady Gaga", gdb.getEmployeeListSize() + 1);
        gdb.addEmployeeToList(lg);
        lg.addWorkload(new WorkSchedule(DayOfWeek.MONDAY, "05:30", "13:30"));
        lg.addWorkload(new WorkSchedule(DayOfWeek.TUESDAY, "05:30", "13:30"));
        lg.addWorkload(new WorkSchedule(DayOfWeek.WEDNESDAY, "05:30", "13:30"));
        lg.addWorkload(new WorkSchedule(DayOfWeek.THURSDAY, "05:30", "13:30"));
        lg.addWorkload(new WorkSchedule(DayOfWeek.FRIDAY, "05:30", "13:30"));
        lg.addWorkload(new WorkSchedule(DayOfWeek.SATURDAY, "05:30", "13:30"));

        Receptionist madona = new Receptionist("Madona", gdb.getEmployeeListSize() + 1);
        gdb.addEmployeeToList(madona);
        madona.addWorkload(new WorkSchedule(DayOfWeek.MONDAY, "13:30", "21:30"));
        madona.addWorkload(new WorkSchedule(DayOfWeek.TUESDAY, "13:30", "21:30"));
        madona.addWorkload(new WorkSchedule(DayOfWeek.WEDNESDAY, "13:30", "21:30"));
        madona.addWorkload(new WorkSchedule(DayOfWeek.THURSDAY, "13:30", "21:30"));
        madona.addWorkload(new WorkSchedule(DayOfWeek.FRIDAY, "13:30", "21:30"));
        madona.addWorkload(new WorkSchedule(DayOfWeek.SATURDAY, "13:30", "21:30"));

        PersonalTrainer popeye = new BodybuildingCoach("Popeye", gdb.getEmployeeListSize() + 1);
        gdb.addEmployeeToList(popeye);
        Customer neymar = new Customer("Neymar", "000.000.000-00", "05/02/1992");
        popeye.addCustomerToList(neymar);
        neymar.addExerciseToWorkoutList(new Workout("10:00", "Hipertrofia"));
        neymar.addExerciseToWorkoutList(new Workout("11:00", "Ergometria"));

        PersonalTrainer phelps = new SwimmingTeacher("Phelps", gdb.getEmployeeListSize() + 1);
        gdb.addEmployeeToList(phelps);
        Customer monica = new Customer("Monica", "111.111.111-11", "01/07/1989");
        phelps.addCustomerToList(monica);
        monica.addExerciseToWorkoutList(new Workout("08:00", "Nado de costas"));
        monica.addExerciseToWorkoutList(new Workout("07:00", "Nado Livre"));
        monica.addExerciseToWorkoutList(new Workout("09:00", "Nado Borboleta"));

        gdb.printReport();
    }
}
